import { useEffect, useState } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { 
  BarChart3, 
  FileSearch, 
  Shield, 
  AlertTriangle,
  TrendingUp,
  Clock,
  Download,
  Filter,
  Search,
  Image,
  Video,
  AudioLines,
  ChevronRight,
  Calendar
} from "lucide-react";
import { Link } from "react-router-dom";

type Scan = {
  id: string;
  file_name: string;
  file_type: string;
  result: string;
  confidence: number;
  created_at: string;
  preview_url: string | null;
};

type Stats = {
  totalScans: number;
  deepfakesFound: number;
  authenticMedia: number;
  avgConfidence: number;
};

const Dashboard = () => {
  const { user } = useAuth();
  const [allScans, setAllScans] = useState<Scan[]>([]);
  const [recentScans, setRecentScans] = useState<Scan[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalScans: 0,
    deepfakesFound: 0,
    authenticMedia: 0,
    avgConfidence: 0,
  });
  const [loading, setLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState<Scan | null>(null);
  const [analyticsOpen, setAnalyticsOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  const fetchUserData = async () => {
    if (!user) return;

    try {
      const { data: scans, error } = await supabase
        .from('scans')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error("Error fetching scans:", error);
        return;
      }

      const scanList = scans || [];
      const totalScans = scanList.length;
      const deepfakesFound = scanList.filter(s => s.result === 'deepfake').length;
      const authenticMedia = scanList.filter(s => s.result === 'authentic').length;
      const avgConfidence = totalScans > 0
        ? scanList.reduce((sum, s) => sum + Number(s.confidence), 0) / totalScans
        : 0;

      setStats({ totalScans, deepfakesFound, authenticMedia, avgConfidence });
      setAllScans(scanList);
      setRecentScans(scanList.slice(0, 5));
    } catch (err) {
      console.error("Failed to fetch user data:", err);
    } finally {
      setLoading(false);
    }
  };

  const exportReport = () => {
    if (allScans.length === 0) {
      toast.info("No scans to export yet");
      return;
    }
    const headers = ["File Name", "Type", "Result", "Confidence (%)", "Date"];
    const escape = (v: string) => `"${String(v).replace(/"/g, '""')}"`;
    const rows = allScans.map(s => [
      escape(s.file_name),
      s.file_type,
      s.result,
      Number(s.confidence).toFixed(2),
      new Date(s.created_at).toISOString(),
    ].join(","));
    const csv = [headers.map(escape).join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deepguard-scans-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Report downloaded");
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "image":
        return <Image className="h-4 w-4" />;
      case "video":
        return <Video className="h-4 w-4" />;
      case "audio":
        return <AudioLines className="h-4 w-4" />;
      default:
        return <FileSearch className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString();
  };

  const statsData = [
    { label: "Total Scans", value: stats.totalScans.toString(), icon: FileSearch },
    { label: "Deepfakes Found", value: stats.deepfakesFound.toString(), icon: AlertTriangle },
    { label: "Authentic Media", value: stats.authenticMedia.toString(), icon: Shield },
    { label: "Avg. Confidence", value: `${stats.avgConfidence.toFixed(1)}%`, icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="noise-overlay" />
      <Navbar />
      
      <main className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">Dashboard</h1>
              <p className="text-muted-foreground">
                Monitor your detection activity and analytics
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline">
                <Calendar className="mr-2 h-4 w-4" />
                Last 30 days
              </Button>
              <Link to="/detect">
                <Button className="btn-glow bg-primary text-primary-foreground">
                  <FileSearch className="mr-2 h-4 w-4" />
                  New Scan
                </Button>
              </Link>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {statsData.map((stat) => (
              <div key={stat.label} className="glass-card p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <stat.icon className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <p className="text-2xl font-bold mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Scans */}
            <div className="lg:col-span-2 glass-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold">Recent Scans</h2>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {loading ? (
                <div className="text-center py-8 text-muted-foreground">
                  Loading scans...
                </div>
              ) : recentScans.length === 0 ? (
                <div className="text-center py-8">
                  <FileSearch className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No scans yet</p>
                  <Link to="/detect">
                    <Button className="mt-4">Start your first scan</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentScans.map((scan) => (
                    <button
                      type="button"
                      key={scan.id}
                      onClick={() => setSelectedScan(scan)}
                      className="w-full text-left flex items-center gap-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-card flex items-center justify-center overflow-hidden">
                        {scan.preview_url && scan.file_type === "image" ? (
                          <img src={scan.preview_url} alt={scan.file_name} className="w-full h-full object-cover" />
                        ) : (
                          getTypeIcon(scan.file_type)
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{scan.file_name}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-2">
                          <Clock className="h-3 w-3" />
                          {formatDate(scan.created_at)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p
                          className={`font-bold ${
                            scan.result === "deepfake"
                              ? "text-destructive"
                              : "text-success"
                          }`}
                        >
                          {Number(scan.confidence).toFixed(1)}%
                        </p>
                        <p
                          className={`text-xs capitalize ${
                            scan.result === "deepfake"
                              ? "text-destructive"
                              : "text-success"
                          }`}
                        >
                          {scan.result}
                        </p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                    </button>
                  ))}
                </div>
              )}

              {recentScans.length > 0 && (
                <Button variant="ghost" className="w-full mt-4">
                  View All Scans
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" onClick={exportReport}>
                    <Download className="mr-2 h-4 w-4" />
                    Export Report
                  </Button>
                  <Button variant="outline" className="w-full justify-start" onClick={() => setAnalyticsOpen(true)}>
                    <BarChart3 className="mr-2 h-4 w-4" />
                    View Analytics
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Preview Dialog */}
      <Dialog open={!!selectedScan} onOpenChange={(open) => !open && setSelectedScan(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="truncate">{selectedScan?.file_name}</DialogTitle>
            <DialogDescription>Preview of your scanned file</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selectedScan?.preview_url && selectedScan.file_type === "image" ? (
              <div className="rounded-lg overflow-hidden bg-muted flex items-center justify-center max-h-[60vh]">
                <img
                  src={selectedScan.preview_url}
                  alt={selectedScan.file_name}
                  className="w-full h-auto object-contain max-h-[60vh]"
                />
              </div>
            ) : (
              <div className="rounded-lg bg-muted p-12 text-center text-muted-foreground">
                <FileSearch className="h-12 w-12 mx-auto mb-3" />
                <p>No preview available for this file.</p>
                <p className="text-xs mt-1">Previews are stored for images up to 10 MB.</p>
              </div>
            )}
            {selectedScan && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground capitalize">{selectedScan.file_type}</span>
                <span
                  className={`font-bold ${
                    selectedScan.result === "deepfake" ? "text-destructive" : "text-success"
                  }`}
                >
                  {selectedScan.result.toUpperCase()} • {Number(selectedScan.confidence).toFixed(1)}%
                </span>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Analytics Dialog */}
      <Dialog open={analyticsOpen} onOpenChange={setAnalyticsOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Analytics Overview</DialogTitle>
            <DialogDescription>
              A breakdown of your detection activity to date.
            </DialogDescription>
          </DialogHeader>
          {(() => {
            const images = allScans.filter(s => s.file_type === "image").length;
            const videos = allScans.filter(s => s.file_type === "video").length;
            const audio = allScans.filter(s => s.file_type === "audio").length;
            const total = images + videos + audio;
            const deepfakeRate = stats.totalScans > 0
              ? (stats.deepfakesFound / stats.totalScans) * 100
              : 0;
            return (
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/40">
                    <p className="text-xs text-muted-foreground">Total Scans</p>
                    <p className="text-xl font-bold">{stats.totalScans}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/40">
                    <p className="text-xs text-muted-foreground">Avg. Confidence</p>
                    <p className="text-xl font-bold">{stats.avgConfidence.toFixed(1)}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/40">
                    <p className="text-xs text-muted-foreground">Deepfakes</p>
                    <p className="text-xl font-bold text-destructive">{stats.deepfakesFound}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/40">
                    <p className="text-xs text-muted-foreground">Authentic</p>
                    <p className="text-xl font-bold text-success">{stats.authenticMedia}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium mb-3">Media Type Breakdown</p>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Images</span>
                        <span className="font-medium">{images}</span>
                      </div>
                      <Progress value={total > 0 ? (images / total) * 100 : 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Videos</span>
                        <span className="font-medium">{videos}</span>
                      </div>
                      <Progress value={total > 0 ? (videos / total) * 100 : 0} className="h-2 [&>div]:bg-secondary" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Audio</span>
                        <span className="font-medium">{audio}</span>
                      </div>
                      <Progress value={total > 0 ? (audio / total) * 100 : 0} className="h-2 [&>div]:bg-warning" />
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-muted-foreground">Deepfake Rate</span>
                    <span className="font-medium">{deepfakeRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={deepfakeRate} className="h-2 [&>div]:bg-destructive" />
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default Dashboard;