ALTER TABLE public.scans ADD COLUMN IF NOT EXISTS preview_url text;

INSERT INTO storage.buckets (id, name, public)
VALUES ('scan-previews', 'scan-previews', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Scan previews are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'scan-previews');

CREATE POLICY "Users can upload their own scan previews"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'scan-previews'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own scan previews"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'scan-previews'
  AND auth.uid()::text = (storage.foldername(name))[1]
);