import { 
  Image, 
  Video, 
  AudioLines, 
  FileText, 
  BarChart3, 
  Zap,
  Lock,
  Globe
} from "lucide-react";

const features = [
  {
    icon: Image,
    title: "Image Analysis",
    description: "Detect face swaps, AI-generated faces, and manipulated photos with pixel-level precision.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Video,
    title: "Video Detection",
    description: "Analyze video frames for deepfake artifacts, lip-sync inconsistencies, and temporal anomalies.",
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    icon: AudioLines,
    title: "Audio Verification",
    description: "Identify voice cloning, synthetic speech, and audio manipulation through spectrogram analysis.",
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    icon: FileText,
    title: "Detailed Reports",
    description: "Generate comprehensive PDF reports with evidence, confidence scores, and visual heatmaps.",
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    description: "Track detection trends, usage statistics, and threat patterns across your organization.",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Zap,
    title: "API Integration",
    description: "RESTful API with SDKs for Python, JavaScript, and more. Process thousands of files programmatically.",
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    icon: Lock,
    title: "Enterprise Security",
    description: "SOC 2 compliant infrastructure with end-to-end encryption. Your data never leaves secure servers.",
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    icon: Globe,
    title: "Global CDN",
    description: "Lightning-fast analysis from edge locations worldwide. Sub-second response times guaranteed.",
    color: "text-success",
    bgColor: "bg-success/10",
  },
];

const FeaturesSection = () => {
  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Complete Detection <span className="text-gradient">Arsenal</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            State-of-the-art AI models trained on millions of synthetic media samples to detect even the most sophisticated deepfakes.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="glass-card p-6 hover:bg-card/70 transition-all duration-300 group cursor-pointer animate-fade-in"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div className={`w-12 h-12 rounded-xl ${feature.bgColor} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className={`h-6 w-6 ${feature.color}`} />
              </div>
              <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
