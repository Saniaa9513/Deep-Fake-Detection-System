import { Link } from "react-router-dom";
import { Shield, Github, Twitter, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t border-border/50 bg-card/30">
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center text-center gap-4 max-w-xl mx-auto">
          <Link to="/" className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-lg font-bold">
              Deep<span className="text-gradient">Guard</span>
            </span>
          </Link>
          <p className="text-sm text-muted-foreground">
            AI-powered deepfake detection for journalists, researchers, and businesses.
          </p>
          <Link
            to="/detect"
            className="text-sm font-medium text-primary hover:underline"
          >
            Deepfake Detection
          </Link>
          <div className="flex gap-4">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              <Github className="h-5 w-5" />
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
              <Linkedin className="h-5 w-5" />
            </a>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} DeepGuard AI. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Protecting truth in the age of AI
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
