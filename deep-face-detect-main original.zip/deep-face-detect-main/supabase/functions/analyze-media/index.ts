import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Enhanced prompts for different analysis focuses
const getSystemPrompt = (focus: string) => {
  const baseContext = `You are an EXPERT AI forensics analyst specializing in detecting AI-generated images.

CRITICAL: Modern AI (Midjourney v6, DALL-E 3, Stable Diffusion XL, Flux, Imagen 3) creates EXTREMELY realistic images. Be VERY SKEPTICAL. When in doubt, classify as AI-generated.`;

  const focusPrompts: Record<string, string> = {
    general: `${baseContext}

## STRONG INDICATORS OF AI GENERATION (any ONE = likely AI):

### SKIN & TEXTURE
- TOO PERFECT: Skin is airbrushed, lacks visible pores, blemishes, or natural texture variation
- PLASTIC/WAXY: Skin has an artificial sheen or looks like silicone
- UNIFORM TEXTURE: Same texture across different skin areas (face, hands, neck)

### ANATOMICAL ERRORS
- HAND ANOMALIES: Wrong finger count, merged/extra fingers, impossible poses, missing knuckles
- EYE ISSUES: Asymmetric reflections, mismatched catchlights, perfect circles for irises
- TEETH: Too uniform, blurred, or merged teeth
- EARS: Asymmetric, malformed, or missing details
- HAIR: Strands merge together, unnatural shine, hair defies physics

### LIGHTING & COMPOSITION
- PERFECT LIGHTING: Too cinematic/dramatic without natural imperfections
- IMPOSSIBLE SHADOWS: Shadows don't match light sources
- PERFECT BOKEH: Background blur is mathematically perfect
- STOCK PHOTO LOOK: Looks like a professional advertisement

### AI-SPECIFIC ARTIFACTS
- MIDJOURNEY: Dreamy quality, over-saturated colors, fantasy aesthetic, distinctive "painted" look
- DALL-E 3: Clean but sometimes overly smooth, text integration issues, specific color palette
- STABLE DIFFUSION: Noise patterns in solid colors, warping at image edges
- FLUX: High detail but sometimes uncanny proportions, specific rendering style

### BACKGROUND ISSUES
- MELTED PEOPLE: Background figures are blobby, lack features
- NONSENSE TEXT: Text in signs/labels is gibberish or malformed
- ARCHITECTURAL ERRORS: Impossible perspectives, warped buildings
- REPEATING PATTERNS: Unnatural repetition in textures

## REAL PHOTO INDICATORS:
- Natural imperfections (blemishes, asymmetry, motion blur)
- Camera sensor noise/grain
- Realistic lens artifacts (chromatic aberration, barrel distortion)
- Logical, detailed backgrounds with real-world imperfections`,

    faces: `${baseContext}

## FACE-SPECIFIC DEEP ANALYSIS:

### SKIN ANALYSIS
- Check for visible pores at full zoom
- Look for natural skin texture variation (oily T-zone, dry patches)
- Examine for tiny imperfections (moles, freckles with irregular shapes)
- Verify realistic subsurface scattering near ears and nose

### EYE FORENSICS
- Catchlight consistency (should match same light source)
- Iris detail and natural irregularities
- Sclera (white of eye) should have tiny blood vessels
- Pupil shape and size consistency between eyes
- Eyelash naturalness (not too perfect or symmetric)

### FACIAL STRUCTURE
- Natural asymmetry in face (one eye slightly higher, etc.)
- Realistic ear detail and cartilage structure
- Natural hairline with baby hairs
- Skin folds and wrinkles should be anatomically correct

### EXPRESSION ANALYSIS
- Micro-expressions should be consistent
- Crow's feet when smiling
- Forehead wrinkles appropriate to expression
- Lip texture and natural color variation`,

    artifacts: `${baseContext}

## TECHNICAL ARTIFACT DEEP ANALYSIS:

### COMPRESSION & RENDERING
- JPEG artifacts should be consistent across image
- Look for AI "seams" where different generations were merged
- Check edges of objects for unnatural sharpness or blur
- Examine solid color areas for noise patterns

### GEOMETRIC ANALYSIS
- Perspective consistency throughout image
- Proportions of objects/people should be realistic
- Symmetry analysis (AI often makes things too symmetric)
- Edge coherence where objects meet

### TEXTURE PATTERNS
- Fabric textures should be consistent with material type
- Metal reflections should match environment
- Glass/transparent surfaces should have correct refraction
- Wood grain and natural patterns should be irregular

### GENERATOR-SPECIFIC TELLS
- MIDJOURNEY V6: Distinctive handling of fine details, specific noise pattern
- DALL-E 3: Color banding in gradients, specific edge treatment
- STABLE DIFFUSION XL: Characteristic upscaling artifacts
- FLUX: Specific approach to photorealism, lighting patterns
- IMAGEN: Google's specific rendering quirks`
  };

  return focusPrompts[focus] || focusPrompts.general;
};

const analyzeWithModel = async (
  model: string,
  imageBase64: string,
  fileName: string,
  focus: string,
  apiKey: string
): Promise<any> => {
  const systemPrompt = getSystemPrompt(focus);
  
  const userContent: any[] = [
    {
      type: "text",
      text: `CAREFULLY analyze this image "${fileName}" focusing on ${focus} aspects. Be EXTREMELY SKEPTICAL - modern AI creates very convincing images. If it looks "too perfect" or "too polished", it's probably AI-generated.

Return ONLY valid JSON:
{
  "isDeepfake": boolean,
  "confidence": number (0-100),
  "summary": "detailed explanation",
  "aiGenerationScore": number (0-100, BE VERY SUSPICIOUS),
  "authenticityScore": number (0-100),
  "manipulationScore": number (0-100),
  "details": {
    "faceManipulation": number (0-100),
    "compressionAnomalies": number (0-100),
    "aiArtifacts": number (0-100),
    "textureAnalysis": number (0-100),
    "lightingConsistency": number (0-100)
  },
  "indicators": ["specific observations"],
  "suspectedGenerator": "none" | "midjourney" | "dalle" | "stable-diffusion" | "flux" | "unknown-ai"
}`
    },
    {
      type: "image_url",
      image_url: {
        url: imageBase64.startsWith("data:") ? imageBase64 : `data:image/jpeg;base64,${imageBase64}`
      }
    }
  ];

  // Use max_completion_tokens for OpenAI models, max_tokens for others
  const isOpenAI = model.startsWith("openai/");
  const tokenParam = isOpenAI 
    ? { max_completion_tokens: 1500 } 
    : { max_tokens: 1500 };

  const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent }
      ],
      ...tokenParam,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`Model ${model} error:`, response.status, errorText);
    throw new Error(`Model ${model} failed: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  
  if (!content) {
    throw new Error("No content in response");
  }

  // Parse JSON from response
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error("No JSON found in response");
  }
  
  return JSON.parse(jsonMatch[0]);
};

const combineResults = (results: any[]): any => {
  const validResults = results.filter(r => r !== null);
  
  if (validResults.length === 0) {
    return null;
  }

  // Weight results: give more weight to higher scores (more suspicious)
  const weightedAverage = (key: string) => {
    const values = validResults.map(r => {
      const val = key.includes('.') 
        ? key.split('.').reduce((obj, k) => obj?.[k], r)
        : r[key];
      return typeof val === 'number' ? val : 0;
    });
    
    // Use quadratic mean for scores to emphasize higher values
    const sum = values.reduce((acc, val) => acc + val * val, 0);
    return Math.sqrt(sum / values.length);
  };

  // Combine indicators from all analyses
  const allIndicators = validResults.flatMap(r => r.indicators || []);
  const uniqueIndicators = [...new Set(allIndicators)];

  // Determine suspected generator by voting
  const generators = validResults
    .map(r => r.suspectedGenerator)
    .filter((g): g is string => typeof g === 'string' && g !== "none");
  const generatorCounts = generators.reduce((acc: Record<string, number>, g: string) => {
    acc[g] = (acc[g] || 0) + 1;
    return acc;
  }, {});
  const sortedGenerators = Object.entries(generatorCounts)
    .sort((a, b) => (b[1] as number) - (a[1] as number));
  const topGenerator = sortedGenerators.length > 0 ? sortedGenerators[0][0] : "none";

  // Combine summaries
  const summaries = validResults.map(r => r.summary).filter(Boolean);
  const combinedSummary = summaries.length > 0 
    ? `Multi-model analysis: ${summaries[0]}` 
    : "Analysis complete";

  // Calculate combined scores with emphasis on suspicious findings
  const aiScore = weightedAverage('aiGenerationScore');
  const manipulation = weightedAverage('manipulationScore');
  
  // If ANY model is highly confident it's AI, boost the overall score
  const maxAiScore = Math.max(...validResults.map(r => r.aiGenerationScore || 0));
  const maxConfidence = Math.max(...validResults.map(r => r.confidence || 0));
  
  // Boost score if any model is very confident
  const boostedAiScore = maxAiScore > 70 
    ? Math.min(100, (aiScore * 0.6) + (maxAiScore * 0.4))
    : aiScore;

  return {
    isDeepfake: boostedAiScore > 50,
    confidence: Math.round((maxConfidence + weightedAverage('confidence')) / 2),
    summary: combinedSummary,
    aiGenerationScore: Math.round(boostedAiScore),
    authenticityScore: Math.round(100 - boostedAiScore),
    manipulationScore: Math.round(manipulation),
    details: {
      faceManipulation: Math.round(weightedAverage('details.faceManipulation')),
      audioArtifacts: 0,
      temporalInconsistency: 0,
      compressionAnomalies: Math.round(weightedAverage('details.compressionAnomalies')),
      aiArtifacts: Math.round(weightedAverage('details.aiArtifacts')),
      metadataAnomaly: 0,
      textureAnalysis: Math.round(weightedAverage('details.textureAnalysis')),
      lightingConsistency: Math.round(weightedAverage('details.lightingConsistency')),
    },
    indicators: uniqueIndicators.slice(0, 10), // Top 10 indicators
    suspectedGenerator: topGenerator,
    analysisMethod: "ensemble-multipass",
    modelsUsed: validResults.length,
  };
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageBase64, fileType, fileName } = await req.json();
    
    if (!imageBase64) {
      return new Response(
        JSON.stringify({ error: "No media data provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      return new Response(
        JSON.stringify({ error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Starting comprehensive analysis of ${fileType} file: ${fileName}`);

    // Handle non-image file types
    if (fileType === "video" || fileType === "audio") {
      // Video and audio analysis requires frame extraction which isn't supported by vision APIs
      // Return a clear message about limitations
      return new Response(
        JSON.stringify({
          isDeepfake: false,
          confidence: 0,
          summary: `${fileType === "video" ? "Video" : "Audio"} analysis is currently limited. For accurate deepfake detection of ${fileType} files, please extract key frames as images and analyze them individually. Our image analysis uses advanced multi-model AI ensemble detection.`,
          aiGenerationScore: 0,
          authenticityScore: 0,
          manipulationScore: 0,
          details: {
            faceManipulation: 0,
            audioArtifacts: 0,
            temporalInconsistency: 0,
            compressionAnomalies: 0,
            aiArtifacts: 0,
            metadataAnomaly: 0,
            textureAnalysis: 0,
            lightingConsistency: 0,
          },
          indicators: [
            `${fileType === "video" ? "Video" : "Audio"} files require specialized processing`,
            "Please upload images or video screenshots for analysis",
            "Our image detection uses Gemini Pro and GPT-5 ensemble analysis"
          ],
          suspectedGenerator: "none",
          analysisMethod: "file-type-check",
          modelsUsed: 0,
          fileTypeNotSupported: true,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Ensure correct MIME type for images
    let processedBase64 = imageBase64;
    if (!imageBase64.startsWith("data:image/")) {
      // If it doesn't have proper image MIME type, try to extract and fix it
      const base64Match = imageBase64.match(/^data:([^;]+);base64,(.+)$/);
      if (base64Match) {
        const mimeType = base64Match[1];
        const base64Data = base64Match[2];
        // Only proceed if it's actually an image
        if (mimeType.startsWith("image/")) {
          processedBase64 = imageBase64;
        } else {
          console.error(`Invalid MIME type: ${mimeType}`);
          return new Response(
            JSON.stringify({ 
              error: "Invalid file type. Please upload an image (PNG, JPG, WebP).",
              fileTypeNotSupported: true 
            }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    // Multi-model, multi-pass analysis for maximum accuracy (IMAGES ONLY)
    // Use only Gemini models which have better format support
    const analyses = [
      // Gemini Pro - General analysis
      analyzeWithModel("google/gemini-2.5-pro", processedBase64, fileName, "general", LOVABLE_API_KEY),
      // Gemini Pro - Face-specific analysis  
      analyzeWithModel("google/gemini-2.5-pro", processedBase64, fileName, "faces", LOVABLE_API_KEY),
      // Gemini Flash - Quick artifact check (faster, good backup)
      analyzeWithModel("google/gemini-2.5-flash", processedBase64, fileName, "artifacts", LOVABLE_API_KEY),
    ];

    // Run all analyses in parallel
    const results = await Promise.allSettled(analyses);
    
    const successfulResults = results
      .filter((r): r is PromiseFulfilledResult<any> => r.status === "fulfilled")
      .map(r => r.value);
    
    const failedCount = results.filter(r => r.status === "rejected").length;
    
    console.log(`Completed ${successfulResults.length} analyses, ${failedCount} failed`);

    if (successfulResults.length === 0) {
      // Handle rate limit and payment errors
      const rejectedReasons = results
        .filter((r): r is PromiseRejectedResult => r.status === "rejected")
        .map(r => r.reason?.message || "Unknown error");
      
      console.error("All analyses failed. Reasons:", rejectedReasons);
      
      if (rejectedReasons.some(r => r.includes("429"))) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (rejectedReasons.some(r => r.includes("402"))) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add more credits." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "Analysis failed. Please try again with a different image." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Combine results from all successful analyses
    const combinedResult = combineResults(successfulResults);
    
    console.log("Combined analysis result:", JSON.stringify(combinedResult, null, 2));

    return new Response(JSON.stringify(combinedResult), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in analyze-media function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
