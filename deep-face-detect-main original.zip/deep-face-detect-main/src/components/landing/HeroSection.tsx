import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Shield, Play, ArrowRight, Scan } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Effects */}
      <div className="absolute inset-0 grid-pattern" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "1s" }} />
      
      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 backdrop-blur-sm animate-fade-in">
            <Shield className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Deepfake Detection</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight animate-fade-in" style={{ animationDelay: "0.1s" }}>
            Detect Deepfakes
            <br />
            <span className="text-gradient">Before They Deceive</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
            Advanced AI analysis for images, videos, and audio. Trusted by journalists, researchers, and enterprises to verify authenticity and protect against synthetic media threats.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <Link to="/detect">
              <Button size="lg" className="btn-glow bg-primary text-primary-foreground text-lg px-8 h-14">
                <Scan className="mr-2 h-5 w-5" />
                Analyze Media Now
              </Button>
            </Link>
            <Link to="/learn">
              <Button size="lg" variant="outline" className="text-lg px-8 h-14 border-border/50 hover:bg-muted/50">
                <Play className="mr-2 h-5 w-5" />
                Watch Demo
              </Button>
            </Link>
          </div>

          {/* Trust Indicators */}
          <div className="pt-12 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <p className="text-sm text-muted-foreground mb-6">Trusted by leading organizations worldwide</p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-50">
              {["Reuters", "BBC", "MIT", "Stanford", "Forbes", "VICE"].map((org) => (
                <span key={org} className="text-lg font-semibold text-muted-foreground">
                  {org}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Floating Detection Preview */}
        <div className="mt-16 max-w-5xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
          <div className="glass-card p-1 glow-border">
            <div className="bg-card rounded-lg p-6 md:p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-destructive" />
                  <div className="w-3 h-3 rounded-full bg-warning" />
                  <div className="w-3 h-3 rounded-full bg-success" />
                </div>
                <div className="flex-1 bg-muted rounded-lg h-8 flex items-center px-4">
                  <span className="text-xs text-muted-foreground font-mono">deepguard.ai/detect</span>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Upload Area */}
                <div className="border-2 border-dashed border-border rounded-xl p-8 flex flex-col items-center justify-center text-center hover:border-primary/50 transition-colors cursor-pointer group">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <ArrowRight className="h-8 w-8 text-primary rotate-[-90deg]" />
                  </div>
                  <p className="text-foreground font-medium">Drop media file here</p>
                  <p className="text-sm text-muted-foreground mt-1">Images, videos, or audio</p>
                </div>

                {/* Sample Results */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-destructive/20 flex items-center justify-center">
                        <span className="text-destructive font-bold text-sm">AI</span>
                      </div>
                      <div>
                        <p className="font-medium text-sm">sample_video.mp4</p>
                        <p className="text-xs text-muted-foreground">Deepfake Detected</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-destructive font-bold">94%</p>
                      <p className="text-xs text-muted-foreground">Fake</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-success/20 flex items-center justify-center">
                        <Shield className="h-5 w-5 text-success" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">interview.mp3</p>
                        <p className="text-xs text-muted-foreground">Authentic</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-success font-bold">98%</p>
                      <p className="text-xs text-muted-foreground">Real</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
