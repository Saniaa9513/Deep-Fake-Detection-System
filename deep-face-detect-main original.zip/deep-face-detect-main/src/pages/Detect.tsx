import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { 
  Upload, 
  Image, 
  Video, 
  AudioLines, 
  FileWarning,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Download,
  RotateCcw,
  Loader2,
  Eye,
  Shield
} from "lucide-react";

type AnalysisResult = {
  isDeepfake: boolean;
  confidence: number;
  summary?: string;
  aiGenerationScore?: number;
  authenticityScore?: number;
  manipulationScore?: number;
  details: {
    faceManipulation: number;
    audioArtifacts: number;
    temporalInconsistency: number;
    compressionAnomalies: number;
    aiArtifacts?: number;
    metadataAnomaly?: number;
    textureAnalysis?: number;
    lightingConsistency?: number;
  };
  indicators?: string[];
  suspectedGenerator?: string;
  analysisMethod?: string;
  modelsUsed?: number;
  fileTypeNotSupported?: boolean;
};

type FileWithPreview = File & { preview?: string };

const Detect = () => {
  const { user } = useAuth();
  const [file, setFile] = useState<FileWithPreview | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const selectedFile = acceptedFiles[0] as FileWithPreview;
      selectedFile.preview = URL.createObjectURL(selectedFile);
      setFile(selectedFile);
      setResult(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".png", ".jpg", ".jpeg", ".webp"],
      "video/*": [".mp4", ".webm", ".mov"],
      "audio/*": [".mp3", ".wav", ".m4a"],
    },
    maxFiles: 1,
    maxSize: 100 * 1024 * 1024, // 100MB
  });

  const getFileType = (file: File) => {
    if (file.type.startsWith("image/")) return "image";
    if (file.type.startsWith("video/")) return "video";
    if (file.type.startsWith("audio/")) return "audio";
    return "unknown";
  };

  const getFileIcon = (file: File) => {
    const type = getFileType(file);
    switch (type) {
      case "image":
        return <Image className="h-8 w-8 text-primary" />;
      case "video":
        return <Video className="h-8 w-8 text-secondary" />;
      case "audio":
        return <AudioLines className="h-8 w-8 text-warning" />;
      default:
        return <FileWarning className="h-8 w-8 text-muted-foreground" />;
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const analyzeMedia = async () => {
    if (!file) return;

    setAnalyzing(true);
    setProgress(0);

    // Progress animation
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return prev;
        }
        return prev + Math.random() * 10;
      });
    }, 300);

    try {
      // Convert file to base64
      const base64 = await fileToBase64(file);
      const fileType = getFileType(file);

      // Call the edge function
      const { data, error } = await supabase.functions.invoke("analyze-media", {
        body: {
          imageBase64: base64,
          fileType: fileType,
          fileName: file.name,
        },
      });

      clearInterval(progressInterval);
      setProgress(100);

      if (error) {
        console.error("Analysis error:", error);
        toast.error(error.message || "Failed to analyze media");
        setAnalyzing(false);
        return;
      }

      if (data.error) {
        toast.error(data.error);
        setAnalyzing(false);
        return;
      }

      const analysisResult = data as AnalysisResult;
      setResult(analysisResult);

      // Save scan to database if user is logged in and file type is supported
      if (user && !analysisResult.fileTypeNotSupported) {
        const scanResult = analysisResult.isDeepfake ? 'deepfake' : 'authentic';

        // Upload preview (images only, max 10MB)
        let previewUrl: string | null = null;
        if (getFileType(file) === 'image' && file.size <= 10 * 1024 * 1024) {
          const ext = file.name.split('.').pop() || 'png';
          const filePath = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
          const { error: uploadError } = await supabase.storage
            .from('scan-previews')
            .upload(filePath, file, { contentType: file.type });
          if (uploadError) {
            console.error("Failed to upload preview:", uploadError);
          } else {
            const { data: urlData } = supabase.storage
              .from('scan-previews')
              .getPublicUrl(filePath);
            previewUrl = urlData.publicUrl;
          }
        }

        const { error: insertError } = await supabase.from('scans').insert({
          user_id: user.id,
          file_name: file.name,
          file_type: getFileType(file),
          result: scanResult,
          confidence: analysisResult.confidence,
          preview_url: previewUrl,
        });

        if (insertError) {
          console.error("Failed to save scan:", insertError);
        }
      }

      toast.success("Analysis complete!");
    } catch (err) {
      console.error("Analysis failed:", err);
      toast.error("Failed to analyze media. Please try again.");
      clearInterval(progressInterval);
    } finally {
      setAnalyzing(false);
    }
  };

  const resetAnalysis = () => {
    if (file?.preview) {
      URL.revokeObjectURL(file.preview);
    }
    setFile(null);
    setResult(null);
    setProgress(0);
  };

  const exportReport = async () => {
    if (!result || !file) return;
    try {
      const { default: jsPDF } = await import("jspdf");
      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 40;
      let y = 50;

      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("DeepGuard AI - Detection Report", margin, y);
      y += 24;

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(120);
      doc.text(`Generated: ${new Date().toLocaleString()}`, margin, y);
      y += 24;
      doc.setTextColor(0);

      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("File", margin, y); y += 16;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const fileLines = doc.splitTextToSize(
        `Name: ${file.name}\nType: ${getFileType(file).toUpperCase()}\nSize: ${(file.size / (1024 * 1024)).toFixed(2)} MB`,
        pageWidth - margin * 2
      );
      doc.text(fileLines, margin, y); y += fileLines.length * 14 + 10;

      // Embed image preview (images only)
      if (getFileType(file) === "image" && file.preview) {
        try {
          const dataUrl = await fileToBase64(file);
          const fmt = (file.type.includes("png") ? "PNG" : file.type.includes("webp") ? "WEBP" : "JPEG") as "PNG" | "JPEG" | "WEBP";
          const img = await new Promise<HTMLImageElement>((resolve, reject) => {
            const i = new window.Image();
            i.onload = () => resolve(i);
            i.onerror = reject;
            i.src = dataUrl;
          });
          const maxW = pageWidth - margin * 2;
          const maxH = 240;
          const ratio = Math.min(maxW / img.width, maxH / img.height);
          const w = img.width * ratio;
          const h = img.height * ratio;
          if (y + h > 780) { doc.addPage(); y = 50; }
          doc.setFont("helvetica", "bold");
          doc.text("Preview", margin, y); y += 16;
          doc.addImage(dataUrl, fmt, margin, y, w, h);
          y += h + 16;
        } catch (e) {
          console.warn("Could not embed preview:", e);
        }
      }

      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Verdict", margin, y); y += 16;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      const verdict = result.fileTypeNotSupported
        ? "Limited Analysis"
        : result.isDeepfake
          ? "Deepfake Detected"
          : "Likely Authentic";
      doc.text(`Result: ${verdict}`, margin, y); y += 14;
      doc.text(`Confidence: ${result.confidence.toFixed(1)}%`, margin, y); y += 14;
      if (result.aiGenerationScore != null) {
        doc.text(`AI Generation Score: ${result.aiGenerationScore.toFixed(0)}%`, margin, y); y += 14;
      }
      if (result.authenticityScore != null) {
        doc.text(`Authenticity Score: ${result.authenticityScore.toFixed(0)}%`, margin, y); y += 14;
      }
      if (result.manipulationScore != null) {
        doc.text(`Manipulation Score: ${result.manipulationScore.toFixed(0)}%`, margin, y); y += 14;
      }
      y += 8;

      if (result.summary) {
        doc.setFont("helvetica", "bold");
        doc.text("Summary", margin, y); y += 16;
        doc.setFont("helvetica", "normal");
        const summaryLines = doc.splitTextToSize(result.summary, pageWidth - margin * 2);
        doc.text(summaryLines, margin, y); y += summaryLines.length * 14 + 10;
      }

      if (result.details && !result.fileTypeNotSupported) {
        doc.setFont("helvetica", "bold");
        doc.text("Detection Signals", margin, y); y += 16;
        doc.setFont("helvetica", "normal");
        Object.entries(result.details).forEach(([key, value]) => {
          const label = key.replace(/([A-Z])/g, " $1").trim();
          doc.text(`- ${label}: ${value.toFixed(1)}%`, margin, y);
          y += 14;
          if (y > 780) { doc.addPage(); y = 50; }
        });
        y += 6;
      }

      if (result.indicators && result.indicators.length > 0) {
        if (y > 720) { doc.addPage(); y = 50; }
        doc.setFont("helvetica", "bold");
        doc.text("AI Analysis Indicators", margin, y); y += 16;
        doc.setFont("helvetica", "normal");
        result.indicators.forEach((ind) => {
          const lines = doc.splitTextToSize(`- ${ind}`, pageWidth - margin * 2);
          doc.text(lines, margin, y);
          y += lines.length * 14;
          if (y > 780) { doc.addPage(); y = 50; }
        });
      }

      const safeName = file.name.replace(/[^a-z0-9._-]+/gi, "_");
      doc.save(`deepguard-report-${safeName}.pdf`);
      toast.success("Report exported");
    } catch (err) {
      console.error("Export failed:", err);
      toast.error("Failed to export report");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="noise-overlay" />
      <Navbar />
      
      <main className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Deepfake <span className="text-gradient">Detection</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              Upload an image, video, or audio file to analyze it for signs of AI manipulation.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {!file ? (
              /* Upload Zone */
              <div
                {...getRootProps()}
                className={`glass-card p-12 text-center cursor-pointer transition-all duration-300 ${
                  isDragActive
                    ? "border-primary bg-primary/5 scale-[1.02]"
                    : "border-border hover:border-primary/50"
                } border-2 border-dashed rounded-2xl`}
              >
                <input {...getInputProps()} />
                <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Upload className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">
                  {isDragActive ? "Drop your file here" : "Drag & drop media file"}
                </h3>
                <p className="text-muted-foreground mb-4">
                  or click to browse from your device
                </p>
                <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Image className="h-4 w-4" />
                    <span>Images (PNG, JPG, WebP)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Video className="h-4 w-4" />
                    <span>Videos (MP4, WebM, MOV)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AudioLines className="h-4 w-4" />
                    <span>Audio (MP3, WAV, M4A)</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-4">Maximum file size: 100MB</p>
              </div>
            ) : (
              /* Analysis View */
              <div className="space-y-6">
                {/* File Preview Card */}
                <div className="glass-card p-6">
                  <div className="flex items-start gap-4">
                    {/* Preview */}
                    <div className="w-32 h-32 rounded-xl bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                      {file.preview && getFileType(file) === "image" ? (
                        <img
                          src={file.preview}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : file.preview && getFileType(file) === "video" ? (
                        <video
                          src={file.preview}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        getFileIcon(file)
                      )}
                    </div>

                    {/* File Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg truncate">{file.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">
                        {(file.size / (1024 * 1024)).toFixed(2)} MB • {getFileType(file).toUpperCase()}
                      </p>
                      
                      {analyzing && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm text-primary">
                            <Loader2 className="h-4 w-4 animate-spin" />
                            <span>Analyzing media...</span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      {!analyzing && !result && (
                        <Button
                          onClick={analyzeMedia}
                          className="btn-glow bg-primary text-primary-foreground"
                        >
                          <Eye className="mr-2 h-4 w-4" />
                          Analyze
                        </Button>
                      )}
                      <Button variant="outline" onClick={resetAnalysis}>
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Reset
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Results */}
                {result && (
                  <div className="space-y-6 animate-fade-in">
                    {/* File Type Not Supported Notice */}
                    {result.fileTypeNotSupported && (
                      <div className="glass-card p-8 text-center border-warning/50 border-2">
                        <div className="w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center bg-warning/20">
                          <AlertTriangle className="h-10 w-10 text-warning" />
                        </div>
                        <h2 className="text-2xl font-bold mb-2">Limited Analysis</h2>
                        <p className="text-muted-foreground max-w-lg mx-auto">
                          {result.summary}
                        </p>
                        <div className="flex flex-wrap justify-center gap-2 mt-4">
                          <span className="px-3 py-1 rounded-full bg-warning/10 text-warning text-xs font-medium">
                            For best results, upload images
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Main Result Card - Only show for supported file types */}
                    {!result.fileTypeNotSupported && (
                      <div
                        className={`glass-card p-8 text-center ${
                          result.isDeepfake
                            ? "border-destructive/50"
                            : "border-success/50"
                        } border-2`}
                      >
                        <div
                          className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${
                            result.isDeepfake ? "bg-destructive/20" : "bg-success/20"
                          }`}
                        >
                          {result.isDeepfake ? (
                            <XCircle className="h-10 w-10 text-destructive" />
                          ) : (
                            <CheckCircle2 className="h-10 w-10 text-success" />
                          )}
                        </div>
                        <h2 className="text-2xl font-bold mb-2">
                          {result.isDeepfake ? "Deepfake Detected" : "Likely Authentic"}
                        </h2>
                        <p className="text-4xl font-bold mb-2">
                          <span className={result.isDeepfake ? "text-destructive" : "text-success"}>
                            {result.confidence.toFixed(1)}%
                          </span>
                        </p>
                        <p className="text-muted-foreground max-w-lg mx-auto">
                          {result.summary || (result.isDeepfake
                            ? "This media shows strong signs of AI manipulation"
                            : "No significant signs of manipulation detected")}
                        </p>
                        
                        {/* Analysis Method Badge */}
                        <div className="flex flex-wrap justify-center gap-2 mt-4">
                          {result.analysisMethod && (
                            <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                              {result.analysisMethod === "ensemble-multipass" ? "Multi-Model Analysis" : result.analysisMethod}
                            </span>
                          )}
                          {result.modelsUsed && result.modelsUsed > 0 && (
                            <span className="px-3 py-1 rounded-full bg-secondary/10 text-secondary text-xs font-medium">
                              {result.modelsUsed} AI Models Used
                            </span>
                          )}
                          {result.suspectedGenerator && result.suspectedGenerator !== "none" && (
                            <span className="px-3 py-1 rounded-full bg-destructive/10 text-destructive text-xs font-medium">
                              Suspected: {result.suspectedGenerator.replace("-", " ").toUpperCase()}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Key Metrics Cards - Only show for supported file types */}
                    {!result.fileTypeNotSupported && (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="glass-card p-6 text-center">
                          <div className="text-sm text-muted-foreground mb-2">AI Generation Score</div>
                          <div className={`text-3xl font-bold ${
                            (result.aiGenerationScore ?? 0) > 50 ? "text-destructive" : "text-success"
                          }`}>
                            {(result.aiGenerationScore ?? 0).toFixed(0)}%
                          </div>
                          <Progress 
                            value={result.aiGenerationScore ?? 0} 
                            className={`h-2 mt-3 ${
                              (result.aiGenerationScore ?? 0) > 50 ? "[&>div]:bg-destructive" : "[&>div]:bg-success"
                            }`} 
                          />
                          <p className="text-xs text-muted-foreground mt-2">
                            Likelihood of AI-generated content
                          </p>
                        </div>

                        <div className="glass-card p-6 text-center">
                          <div className="text-sm text-muted-foreground mb-2">Authenticity Score</div>
                          <div className={`text-3xl font-bold ${
                            (result.authenticityScore ?? 100) > 50 ? "text-success" : "text-destructive"
                          }`}>
                            {(result.authenticityScore ?? 100).toFixed(0)}%
                          </div>
                          <Progress 
                            value={result.authenticityScore ?? 100} 
                            className={`h-2 mt-3 ${
                              (result.authenticityScore ?? 100) > 50 ? "[&>div]:bg-success" : "[&>div]:bg-destructive"
                            }`} 
                          />
                          <p className="text-xs text-muted-foreground mt-2">
                            Confidence media is genuine
                          </p>
                        </div>

                        <div className="glass-card p-6 text-center">
                          <div className="text-sm text-muted-foreground mb-2">Manipulation Score</div>
                          <div className={`text-3xl font-bold ${
                            (result.manipulationScore ?? 0) > 50 ? "text-warning" : "text-success"
                          }`}>
                            {(result.manipulationScore ?? 0).toFixed(0)}%
                          </div>
                          <Progress 
                            value={result.manipulationScore ?? 0} 
                            className={`h-2 mt-3 ${
                              (result.manipulationScore ?? 0) > 50 ? "[&>div]:bg-warning" : "[&>div]:bg-success"
                            }`} 
                          />
                          <p className="text-xs text-muted-foreground mt-2">
                            Signs of editing/tampering
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Detailed Analysis - Only show for supported file types */}
                    {!result.fileTypeNotSupported && (
                      <div className="glass-card p-6">
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5 text-warning" />
                          Detection Signals
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {Object.entries(result.details).map(([key, value]) => (
                            <div key={key} className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground capitalize">
                                  {key.replace(/([A-Z])/g, " $1").trim()}
                                </span>
                                <span className="font-medium">{value.toFixed(1)}%</span>
                              </div>
                              <Progress
                                value={value}
                                className={`h-2 ${
                                  value > 70 ? "[&>div]:bg-destructive" : value > 40 ? "[&>div]:bg-warning" : "[&>div]:bg-success"
                                }`}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* AI Indicators */}
                    {result.indicators && result.indicators.length > 0 && (
                      <div className="glass-card p-6">
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <Eye className="h-5 w-5 text-primary" />
                          AI Analysis Indicators
                        </h3>
                        <ul className="space-y-2">
                          {result.indicators.map((indicator, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <span className="text-primary mt-1">•</span>
                              <span>{indicator}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button
                        variant="outline"
                        className="flex-1 sm:flex-none"
                        onClick={exportReport}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Export Report (PDF)
                      </Button>
                      <Button
                        onClick={resetAnalysis}
                        className="flex-1 sm:flex-none btn-glow bg-primary text-primary-foreground"
                      >
                        <Shield className="mr-2 h-4 w-4" />
                        Analyze Another File
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Detect;
