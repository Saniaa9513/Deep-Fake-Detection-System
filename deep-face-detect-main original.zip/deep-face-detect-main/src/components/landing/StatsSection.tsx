import { TrendingUp, Users, FileSearch, Shield } from "lucide-react";

const stats = [
  {
    icon: FileSearch,
    value: "500K+",
    label: "Media Files Analyzed",
    description: "Images, videos, and audio scanned for manipulation",
  },
  {
    icon: TrendingUp,
    value: "96.8%",
    label: "Detection Accuracy",
    description: "Industry-leading precision in identifying deepfakes",
  },
  {
    icon: Users,
    value: "10K+",
    label: "Active Users",
    description: "Journalists, researchers, and security professionals",
  },
  {
    icon: Shield,
    value: "50M+",
    label: "People Protected",
    description: "From misinformation through verified content",
  },
];

const StatsSection = () => {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/30 to-background" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="glass-card p-6 text-center hover:bg-card/70 transition-all duration-300 group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <stat.icon className="h-7 w-7 text-primary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold text-gradient mb-2">{stat.value}</p>
              <p className="font-semibold text-foreground mb-1">{stat.label}</p>
              <p className="text-sm text-muted-foreground">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
