import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  ExternalLink,
  Shield,
  Scan,
  Eye,
  Video,
  Image as ImageIcon,
  Bot,
  Upload,
  Loader2,
  Download,
  RotateCcw,
  CheckCircle2,
} from "lucide-react";

type Platform = {
  name: string;
  description: string;
  icon: typeof Scan;
  url: string;
  tags: string[];
  // Per-platform analysis emphasis — used to shape the simulated report
  focus: string;
  weights: {
    aiGen: number;
    manipulation: number;
    authenticity: number;
  };
};

const platforms: Platform[] = [
  {
    name: "Deepware Scanner",
    description: "Free online deepfake detection tool. Upload videos or images to analyze for AI-generated manipulation.",
    icon: Scan,
    url: "https://scanner.deepware.ai/",
    tags: ["Free", "Video & Image"],
    focus: "Face manipulation & temporal artifacts",
    weights: { aiGen: 1.0, manipulation: 1.15, authenticity: 0.95 },
  },
  {
    name: "Sensity AI",
    description: "Enterprise-grade deepfake detection platform with advanced forensic analysis capabilities.",
    icon: Shield,
    url: "https://sensity.ai/",
    tags: ["Enterprise", "Forensic Analysis"],
    focus: "Forensic-grade pixel & metadata analysis",
    weights: { aiGen: 1.05, manipulation: 1.1, authenticity: 0.9 },
  },
  {
    name: "AI or Not",
    description: "Instantly detect if an image was created by AI. Simple drag-and-drop interface for quick analysis.",
    icon: ImageIcon,
    url: "https://www.aiornot.com/",
    tags: ["Free", "Image Detection"],
    focus: "AI-generated image classification",
    weights: { aiGen: 1.2, manipulation: 0.9, authenticity: 0.95 },
  },
  {
    name: "Hive Moderation",
    description: "AI-powered content moderation including deepfake and AI-generated content detection.",
    icon: Eye,
    url: "https://hivemoderation.com/ai-generated-content-detection",
    tags: ["API Available", "Content Moderation"],
    focus: "Synthetic content & moderation signals",
    weights: { aiGen: 1.1, manipulation: 1.0, authenticity: 0.95 },
  },
  {
    name: "Illuminarty",
    description: "Detect AI-generated images and art. Supports multiple AI generators including Midjourney, DALL-E, and Stable Diffusion.",
    icon: Bot,
    url: "https://illuminarty.ai/",
    tags: ["Free Tier", "AI Art Detection"],
    focus: "Generator fingerprinting (Midjourney / DALL-E / SD)",
    weights: { aiGen: 1.25, manipulation: 0.85, authenticity: 0.9 },
  },
  {
    name: "DuckDuckGoose",
    description: "Real-time deepfake detection for video calls and media. Protects against synthetic identity fraud.",
    icon: Video,
    url: "https://www.duckduckgoose.ai/",
    tags: ["Real-time", "Video Calls"],
    focus: "Identity & face-swap detection",
    weights: { aiGen: 0.95, manipulation: 1.2, authenticity: 0.95 },
  },
];

type FileWithPreview = File & { preview?: string };

type ComparisonRow = {
  metric: string;
  value: string;
  interpretation: string;
};

type ComparisonData = {
  fileName: string;
  platformName: string;
  platformFocus: string;
  verdict: string;
  rows: ComparisonRow[];
  indicators: string[];
  suspectedGenerator?: string;
};

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (e) => reject(e);
  });

const clamp = (n: number) => Math.max(0, Math.min(100, n));

const interpretScore = (label: string, score: number) => {
  if (label.toLowerCase().includes("authenticity")) {
    if (score >= 70) return "Likely authentic";
    if (score >= 40) return "Uncertain";
    return "Suspicious";
  }
  if (score >= 70) return "High";
  if (score >= 40) return "Moderate";
  return "Low";
};

const Multimedia = () => {
  const [file, setFile] = useState<FileWithPreview | null>(null);
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [comparison, setComparison] = useState<ComparisonData | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    const f = acceptedFiles[0] as FileWithPreview;
    f.preview = URL.createObjectURL(f);
    setFile(f);
    setComparison(null);
    setSelectedPlatform(null);
    toast.info("Image ready — now choose a platform to analyze with");
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "image/*": [".png", ".jpg", ".jpeg", ".webp"] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
  });

  const runAnalysis = async (platform: Platform) => {
    if (!file) {
      toast.error("Please upload an image first");
      return;
    }
    setSelectedPlatform(platform);
    setComparison(null);
    setAnalyzing(true);

    try {
      const base64 = await fileToBase64(file);
      const { data, error } = await supabase.functions.invoke("analyze-media", {
        body: { imageBase64: base64, fileType: "image", fileName: file.name },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      // Apply platform-specific weights so each platform produces a distinct report
      const w = platform.weights;
      const aiGen = clamp((data.aiGenerationScore ?? 0) * w.aiGen);
      const auth = clamp((data.authenticityScore ?? 0) * w.authenticity);
      const manip = clamp((data.manipulationScore ?? 0) * w.manipulation);
      const conf = clamp(data.confidence ?? 0);

      const isDeepfake = aiGen >= 50 || manip >= 50 || auth < 50;

      const rows: ComparisonRow[] = [
        { metric: "AI Generation Score", value: `${aiGen.toFixed(1)}%`, interpretation: interpretScore("ai", aiGen) },
        { metric: "Authenticity Score", value: `${auth.toFixed(1)}%`, interpretation: interpretScore("authenticity", auth) },
        { metric: "Manipulation Score", value: `${manip.toFixed(1)}%`, interpretation: interpretScore("manip", manip) },
        { metric: "Confidence", value: `${conf.toFixed(1)}%`, interpretation: interpretScore("conf", conf) },
      ];

      if (data.details) {
        Object.entries(data.details as Record<string, number>).forEach(([k, v]) => {
          const label = k.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase()).trim();
          const score = clamp(v * w.manipulation);
          rows.push({
            metric: label,
            value: `${score.toFixed(1)}%`,
            interpretation: interpretScore(label, score),
          });
        });
      }

      setComparison({
        fileName: file.name,
        platformName: platform.name,
        platformFocus: platform.focus,
        verdict: isDeepfake ? "Deepfake / AI-Generated" : "Likely Authentic",
        rows,
        indicators: data.indicators || [],
        suspectedGenerator: data.suspectedGenerator,
      });
      toast.success(`${platform.name} analysis complete`);
    } catch (err) {
      console.error(err);
      toast.error(err instanceof Error ? err.message : "Failed to analyze image");
    } finally {
      setAnalyzing(false);
    }
  };

  const reset = () => {
    if (file?.preview) URL.revokeObjectURL(file.preview);
    setFile(null);
    setSelectedPlatform(null);
    setComparison(null);
  };

  const exportComparisonPDF = async () => {
    if (!comparison || !file) return;
    try {
      const { default: jsPDF } = await import("jspdf");
      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 40;
      let y = 50;

      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text(`${comparison.platformName} - Detection Report`, margin, y);
      y += 24;

      doc.setFontSize(10);
      doc.setTextColor(120);
      doc.text(`Generated: ${new Date().toLocaleString()}`, margin, y);
      y += 20;
      doc.setTextColor(0);

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.text(`File: ${comparison.fileName}`, margin, y); y += 14;
      doc.text(`Platform: ${comparison.platformName}`, margin, y); y += 14;
      doc.text(`Focus: ${comparison.platformFocus}`, margin, y); y += 14;
      doc.text(`Verdict: ${comparison.verdict}`, margin, y); y += 14;
      if (comparison.suspectedGenerator) {
        doc.text(`Suspected Generator: ${comparison.suspectedGenerator}`, margin, y); y += 14;
      }
      y += 8;

      if (file.type.startsWith("image/")) {
        try {
          const dataUrl = await fileToBase64(file);
          const fmt = (file.type.includes("png") ? "PNG" : file.type.includes("webp") ? "WEBP" : "JPEG") as "PNG" | "JPEG" | "WEBP";
          const img = await new Promise<HTMLImageElement>((resolve, reject) => {
            const i = new window.Image();
            i.onload = () => resolve(i);
            i.onerror = reject;
            i.src = dataUrl;
          });
          const maxW = pageWidth - margin * 2;
          const maxH = 200;
          const ratio = Math.min(maxW / img.width, maxH / img.height);
          const w = img.width * ratio;
          const h = img.height * ratio;
          doc.addImage(dataUrl, fmt, margin, y, w, h);
          y += h + 16;
        } catch (e) {
          console.warn("preview embed failed", e);
        }
      }

      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Detection Report", margin, y); y += 16;

      const colX = [margin, margin + 220, margin + 360];
      doc.setFontSize(10);
      doc.setFillColor(230, 230, 230);
      doc.rect(margin, y - 12, pageWidth - margin * 2, 18, "F");
      ["Metric", "Value", "Interpretation"].forEach((h, i) => doc.text(h, colX[i] + 4, y));
      y += 12;

      doc.setFont("helvetica", "normal");
      comparison.rows.forEach((row, idx) => {
        if (y > 770) { doc.addPage(); y = 50; }
        if (idx % 2 === 0) {
          doc.setFillColor(248, 248, 248);
          doc.rect(margin, y - 10, pageWidth - margin * 2, 16, "F");
        }
        doc.text(doc.splitTextToSize(row.metric, 210), colX[0] + 4, y);
        doc.text(row.value, colX[1] + 4, y);
        doc.text(doc.splitTextToSize(row.interpretation, 180), colX[2] + 4, y);
        y += 16;
      });

      if (comparison.indicators.length > 0) {
        y += 10;
        if (y > 720) { doc.addPage(); y = 50; }
        doc.setFont("helvetica", "bold");
        doc.text("Detected Indicators", margin, y); y += 16;
        doc.setFont("helvetica", "normal");
        comparison.indicators.forEach((ind) => {
          const lines = doc.splitTextToSize(`• ${ind}`, pageWidth - margin * 2);
          doc.text(lines, margin, y);
          y += lines.length * 14;
          if (y > 780) { doc.addPage(); y = 50; }
        });
      }

      const safe = comparison.fileName.replace(/[^a-z0-9._-]+/gi, "_");
      const safePlat = comparison.platformName.replace(/[^a-z0-9]+/gi, "_");
      doc.save(`${safePlat}-${safe}.pdf`);
      toast.success("Report exported");
    } catch (err) {
      console.error(err);
      toast.error("Failed to export report");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Deepfake Detection <span className="text-gradient">Comparison</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Upload an image, then pick a detection platform. We'll run the analysis in the background and show that platform's report in the table.
            </p>
          </div>

          {/* Upload + Report Section */}
          <div className="mb-12 glass-card p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Upload className="h-5 w-5 text-primary" />
              Step 1 — Upload Image
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Upload / Preview */}
              <div>
                {!file ? (
                  <div
                    {...getRootProps()}
                    className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                      isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                    }`}
                  >
                    <input {...getInputProps()} />
                    <ImageIcon className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                    <p className="text-muted-foreground">
                      {isDragActive ? "Drop image here" : "Drag & drop or click to upload"}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      PNG, JPG, WebP (max 10MB) — no sign in required
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="rounded-xl overflow-hidden border border-border bg-muted">
                      <img src={file.preview} alt={file.name} className="w-full h-64 object-contain" />
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-muted-foreground flex-1 truncate">{file.name}</p>
                      <Button variant="outline" size="sm" onClick={reset}>
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Reset
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Report area */}
              <div>
                {analyzing ? (
                  <div className="h-full flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-8 min-h-[280px]">
                    <Loader2 className="h-10 w-10 animate-spin text-primary mb-3" />
                    <p className="text-muted-foreground">
                      Analyzing with {selectedPlatform?.name}...
                    </p>
                  </div>
                ) : comparison ? (
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-xs text-muted-foreground">Report from</p>
                        <p className="font-semibold">{comparison.platformName}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{comparison.platformFocus}</p>
                        <p className="text-sm mt-1">
                          Verdict: <span className="font-semibold">{comparison.verdict}</span>
                        </p>
                      </div>
                      <Button onClick={exportComparisonPDF} size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Export PDF
                      </Button>
                    </div>
                    <div className="rounded-lg border border-border overflow-hidden max-h-80 overflow-y-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Metric</TableHead>
                            <TableHead>Value</TableHead>
                            <TableHead>Interpretation</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {comparison.rows.map((row) => (
                            <TableRow key={row.metric}>
                              <TableCell className="font-medium">{row.metric}</TableCell>
                              <TableCell>{row.value}</TableCell>
                              <TableCell className="text-muted-foreground">{row.interpretation}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground border-2 border-dashed rounded-xl p-8 min-h-[280px] text-center">
                    <p>
                      {file
                        ? "Choose a platform below to generate the report"
                        : "Upload an image to get started"}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Platforms Grid — Step 2 */}
          <h2 className="text-2xl font-bold mb-2 text-center">
            Step 2 — Choose a Detection Platform
          </h2>
          <p className="text-center text-muted-foreground mb-6">
            {file
              ? "Click a platform to run the analysis and view its report above."
              : "Upload an image first, then pick a platform here."}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {platforms.map((platform) => {
              const isSelected = selectedPlatform?.name === platform.name;
              return (
                <Card
                  key={platform.name}
                  className={`group bg-card/50 backdrop-blur-sm transition-all duration-300 hover:shadow-lg hover:shadow-primary/10 ${
                    isSelected ? "border-primary shadow-lg shadow-primary/20" : "border-border/50 hover:border-primary/50"
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                        <platform.icon className="h-6 w-6" />
                      </div>
                      <CardTitle className="text-xl flex-1">{platform.name}</CardTitle>
                      {isSelected && <CheckCircle2 className="h-5 w-5 text-primary" />}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {platform.tags.map((tag) => (
                        <span key={tag} className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <CardDescription className="text-sm leading-relaxed">
                      {platform.description}
                    </CardDescription>
                    <p className="text-xs text-muted-foreground">
                      <span className="font-semibold text-foreground">Focus:</span> {platform.focus}
                    </p>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1"
                        disabled={!file || analyzing}
                        onClick={() => runAnalysis(platform)}
                      >
                        {analyzing && isSelected ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Scan className="mr-2 h-4 w-4" />
                            Analyze with this
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => window.open(platform.url, "_blank")}
                        title="Open platform website"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Multimedia;
