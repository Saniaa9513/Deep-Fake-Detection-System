-- Create storage bucket for multimedia comparison images
INSERT INTO storage.buckets (id, name, public)
VALUES ('comparison-images', 'comparison-images', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload images
CREATE POLICY "Users can upload comparison images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'comparison-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Allow users to view their own images
CREATE POLICY "Users can view their own comparison images"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'comparison-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Allow users to delete their own images
CREATE POLICY "Users can delete their own comparison images"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'comparison-images' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create table to track comparison sessions
CREATE TABLE public.comparison_images (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.comparison_images ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view their own comparison images"
ON public.comparison_images
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own comparison images"
ON public.comparison_images
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comparison images"
ON public.comparison_images
FOR DELETE
USING (auth.uid() = user_id);