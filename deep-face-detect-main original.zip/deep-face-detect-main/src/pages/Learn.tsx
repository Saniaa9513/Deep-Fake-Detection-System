import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { 
  BookOpen, 
  Brain, 
  Eye, 
  AlertTriangle, 
  Shield, 
  ExternalLink,
  Play,
  ChevronRight,
  Lightbulb,
  Target
} from "lucide-react";
import { Link } from "react-router-dom";

const articles = [
  {
    category: "Fundamentals",
    title: "What Are Deepfakes?",
    description: "Understanding synthetic media: how AI creates convincing fake images, videos, and audio.",
    icon: Brain,
    readTime: "5 min watch",
    featured: true,
    videoUrl: "https://www.youtube.com/watch?v=gLoI9hAX9dw",
  },
  {
    category: "Detection",
    title: "How to Spot a Deepfake",
    description: "Visual and audio cues that reveal AI manipulation in media content.",
    icon: Eye,
    readTime: "8 min watch",
    featured: true,
    videoUrl: "https://www.youtube.com/watch?v=5xUsTan4ZVw",
  },
  {
    category: "Threats",
    title: "The Deepfake Threat Landscape",
    description: "From political disinformation to fraud: understanding the risks of synthetic media.",
    icon: AlertTriangle,
    readTime: "10 min watch",
    featured: false,
    videoUrl: "https://www.youtube.com/watch?v=oxXpB9pSETo",
  },
  {
    category: "Protection",
    title: "Protecting Your Organization",
    description: "Best practices for enterprises to defend against deepfake attacks and verify content.",
    icon: Shield,
    readTime: "12 min watch",
    featured: false,
    videoUrl: "https://www.youtube.com/watch?v=YDNquWvOJyc",
  },
  {
    category: "Technology",
    title: "How AI Detection Works",
    description: "Behind the scenes of deepfake detection: neural networks, artifacts, and analysis methods.",
    icon: Lightbulb,
    readTime: "15 min watch",
    featured: false,
    videoUrl: "https://www.youtube.com/watch?v=mUfJOQKdtAk",
  },
  {
    category: "Case Studies",
    title: "Notable Deepfake Incidents",
    description: "Examining high-profile cases of synthetic media and their impact on society.",
    icon: Target,
    readTime: "7 min watch",
    featured: false,
    videoUrl: "https://www.youtube.com/watch?v=cQ54GDm1eL0",
  },
];

const caseStudies = [
  {
    title: "Political Deepfake Crisis (2024)",
    description: "How a fabricated video nearly influenced a national election, and how verification tools exposed it.",
    impact: "Prevented misinformation reaching 50M+ viewers",
  },
  {
    title: "Corporate Voice Clone Fraud",
    description: "A $25 million wire transfer was initiated using AI-cloned voice of a CEO — detected in time.",
    impact: "Saved company from major financial loss",
  },
  {
    title: "Celebrity Defamation Campaign",
    description: "Synthetic media used to damage a public figure's reputation was traced and debunked.",
    impact: "Legal action enabled through forensic analysis",
  },
];

const Learn = () => {
  return (
    <div className="min-h-screen bg-background">
      <div className="noise-overlay" />
      <Navbar />
      
      <main className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5 mb-6">
              <BookOpen className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Educational Hub</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Learn About <span className="text-gradient">Deepfakes</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              Understand the threat of synthetic media and how to protect yourself and your organization from AI-generated deception.
            </p>
          </div>

          {/* Featured Video */}
          <div className="max-w-4xl mx-auto mb-16">
            <div className="glass-card overflow-hidden glow-border">
              <div className="aspect-video bg-muted relative">
                <iframe
                  className="absolute inset-0 w-full h-full"
                  src="https://www.youtube.com/embed/AmUC4m6w1wo"
                  title="The Rise of Deepfakes: A Visual Explainer"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              </div>
              <div className="p-6">
                <p className="text-sm text-primary mb-2">Featured Video • How Deepfakes Work</p>
                <h3 className="text-xl font-semibold">The Rise of Deepfakes: A Visual Explainer</h3>
              </div>
            </div>
          </div>

          {/* Articles Grid */}
          <section className="mb-20">
            <h2 className="text-2xl font-bold mb-8">Essential Reading</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article, index) => (
                <a
                  key={article.title}
                  href={article.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-card p-6 hover:bg-card/70 transition-all duration-300 group cursor-pointer animate-fade-in block"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <article.icon className="h-6 w-6 text-primary" />
                    </div>
                    {article.featured && (
                      <span className="px-2 py-1 text-xs font-medium bg-primary/20 text-primary rounded-full">
                        Featured
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-primary font-medium mb-2">{article.category}</p>
                  <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                    {article.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">{article.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{article.readTime}</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                </a>
              ))}
            </div>
          </section>

          {/* Case Studies */}
          <section className="mb-20">
            <h2 className="text-2xl font-bold mb-8">Real-World Case Studies</h2>
            <div className="space-y-4">
              {caseStudies.map((study, index) => (
                <div
                  key={study.title}
                  className="glass-card p-6 hover:bg-card/70 transition-all duration-300 cursor-pointer group"
                >
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                        {study.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{study.description}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="px-4 py-2 bg-success/10 rounded-lg">
                        <p className="text-xs text-success font-medium">{study.impact}</p>
                      </div>
                      <ExternalLink className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* CTA */}
          <section className="text-center">
            <div className="glass-card p-8 md:p-12 max-w-2xl mx-auto glow-border">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                Ready to Detect Deepfakes?
              </h2>
              <p className="text-muted-foreground mb-6">
                Put your knowledge to the test. Try our AI-powered detection tool to analyze media files for signs of manipulation.
              </p>
              <Link to="/detect">
                <Button size="lg" className="btn-glow bg-primary text-primary-foreground">
                  <Shield className="mr-2 h-5 w-5" />
                  Start Detecting
                </Button>
              </Link>
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Learn;
